package com.sheridancollege.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityLoginLogoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
