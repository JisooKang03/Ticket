CREATE TABLE BusTicket (
                           FirstName varchar(255),
                           LastName varchar(255),
                           BusTicket varchar(255),
                           Code varchar(255),
                           SeatNumber varchar(255)
);