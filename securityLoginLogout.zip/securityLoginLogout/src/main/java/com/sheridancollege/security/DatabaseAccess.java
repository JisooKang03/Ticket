
package com.sheridancollege.security;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import com.sheridancollege.security.model.Ticket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;



@Repository
public class DatabaseAccess {

	@Autowired
	protected NamedParameterJdbcTemplate jdbc;

	public List<Ticket> getTickets() {
		String sql = "SELECT * FROM ticket";
		return jdbc.query(sql, new BeanPropertyRowMapper<>(Ticket.class));
	}

	// fields are firstName, lastName, bus ticket, seat and code
	public void insertTicket(Ticket ticket) {
		String sql = "INSERT INTO ticket (firstName, lastName, busTicket, seat, code) VALUES (:firstName, :lastName, :busTicket, :seat, :code)";
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("firstName", ticket.getFirstName());
		parameters.addValue("lastName", ticket.getLastName());
		parameters.addValue("busTicket", ticket.getBusTicket());
		parameters.addValue("seat", ticket.getSeat());
		parameters.addValue("code", ticket.getCode());

		jdbc.update(sql, parameters);

	}


	public void deleteTicketById(int id) {
		String sql = "DELETE FROM ticket WHERE id = :id";
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("id", id);

		jdbc.update(sql, parameters);
	}


	public Ticket getTicketById(int id) {
		String sql = "SELECT * FROM ticket WHERE id = :id";
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("id", id);

		return jdbc.queryForObject(sql, parameters, new BeanPropertyRowMapper<>(Ticket.class));
	}

	public void updateTicketById(int id, Ticket ticket) {
		String sql = "UPDATE ticket SET firstName = :firstName, lastName = :lastName, busTicket = :busTicket, seat = :seat, code :code WHERE id = :id";
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("id", id);
		parameters.addValue("firstName", ticket.getFirstName());
		parameters.addValue("lastName", ticket.getLastName());
		parameters.addValue("busTicket", ticket.getBusTicket());
		parameters.addValue("seat", ticket.getSeat());
		parameters.addValue("code", ticket.getCode());

		 jdbc.update(sql, parameters);
	}

}