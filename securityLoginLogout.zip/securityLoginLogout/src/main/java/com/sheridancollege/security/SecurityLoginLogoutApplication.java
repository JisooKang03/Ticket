package com.sheridancollege.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityLoginLogoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityLoginLogoutApplication.class, args);
	}

}
